//
//  TableviewCellTableViewCell.swift
//  Xibcell
//
//  Created by Rp on 15/12/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class TableviewCellTableViewCell: UITableViewCell {

    @IBOutlet var lbl : UILabel!
    @IBOutlet var lblSecound : UILabel!
    @IBOutlet var lblThird : UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        lbl.text = "Abcabakbabbc"
        lbl.textAlignment = .center
        lbl.font = UIFont.boldSystemFont(ofSize: 25)
        lblSecound.text = "nknfjdskbskdsdb"
        lblSecound.textAlignment = .left
        lblSecound.font = UIFont.systemFont(ofSize: 20)
        lblThird.text = "vdsavuasiasda"
        lblThird.textAlignment = .left
        lblThird.font = UIFont.systemFont(ofSize: 20)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
